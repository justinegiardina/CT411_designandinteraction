function setup(){
createCanvas(1024,768);    
    
    
    
}
function draw() {
 background(251,203,204);
  stroke(255);
    strokeWeight(10);
 triangle(612, 500, 512, 300, 412, 500)
fill(255,13,100,100);
    fill(56, 186, 182);
 stroke(255);
    strokeWeight(10);
 ellipse(512,230,95,95); 
 fill(255,13,100,100);
    fill(56, 186, 182);
rect(474, 525, 76, 110)
    fill(56, 186, 182);
 stroke(255);
    strokeWeight(10);
    
    
}